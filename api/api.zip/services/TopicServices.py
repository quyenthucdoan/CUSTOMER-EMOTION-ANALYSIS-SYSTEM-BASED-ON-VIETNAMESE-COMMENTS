from app import db


def getTerms(sentiment, numOfTerms=50):
    sentiment = int(sentiment)
    if sentiment != 0 and sentiment != 1 and sentiment != -1:
        sentiment = 2
    print("sentiment", sentiment)
    if not numOfTerms:
        numOfTerms = 50
    results = []
    for i in range(10):
        query = """
        SELECT keyword, topic, pseudo_freq, sentiment
	    FROM public.topic_terms where sentiment={} and topic={}
        ORDER BY pseudo_freq DESC
        LIMIT {}
        """.format(
            sentiment, i, numOfTerms
        )
        # print(query)
        temps = db.engine.execute(query)
        topic = []
        for item in temps:
            topic.append(dict(item))
        results.append(topic)
    return results
