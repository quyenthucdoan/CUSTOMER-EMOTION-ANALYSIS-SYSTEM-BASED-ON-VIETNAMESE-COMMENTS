from app import app
from services import TopicServices
from flask import jsonify, request

@app.route('/topic/terms', methods=['GET'])
def getTerms():
    sentiment = request.args.get("sentiment")
    numOfTerms = request.args.get("numOfTerms")
    results = TopicServices.getTerms(sentiment, numOfTerms)
    return jsonify({ 'results': results })